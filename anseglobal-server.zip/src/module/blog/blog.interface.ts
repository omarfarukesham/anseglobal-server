export interface IBlog {
    title: string;
    content: string;
    author: string;
    isPublished: boolean;
    createdAt: Date;
    updatedAt: Date;
  }
  
